---
name: cold-email-patterns
description: >
  A skill trained on 10,102 positive email replies (Interested, Information Request, Meeting Request) generated from 1,000,000+ cold outbound emails across 200+ campaigns. Use this skill whenever writing cold outbound email sequences, analyzing email copy performance, optimizing follow-up sequences, creating new campaign messaging, reviewing email copy before launch, or brainstorming outreach strategies. Also use when the user asks about email copywriting best practices, wants to improve reply rates, or needs help crafting B2B outreach for any industry. This skill covers: agency/consultancy outreach, SaaS sales, EdTech pilot programs, recruiting, video production, real estate tech, HR/assessment tools, and manufacturing services.
---

# Cold Email Pattern Analysis Skill

## Source Data Overview

This skill is derived from real campaign data:
- **Total emails sent:** 1,000,000+ (including all follow-ups)
- **Total replies:** 96,200 (9.6% reply rate)
- **Positive replies:** 10,102 (1.01% of sent; 10.5% of all replies)
  - Information Request: 5,112 (50.6% of positive)
  - Interested: 4,718 (46.7% of positive)
  - Meeting Request: 272 (2.7% of positive)
- **Campaigns analyzed:** 200+ across 10+ verticals
- **Time period:** April 2024 – March 2026

---

## QUICK DECISION FRAMEWORK — Start Here

Before reading the full skill, use this router to jump to the right framework:

**What are you selling?**
- **A service** (consulting, agency, B2B services) → Use **Framework A – GTM Roadmap** (3-step, escalating value)
- **A product** (SaaS, hardware, anything with a trial/demo) → Use **Framework B – Free Pilot** (2-step, no-risk offer)
- **A creative/media service** (video, content, design) → Use **Framework C – Emotional Storytelling** (2-step, provocative question)
- **Recruiting/talent** (hiring for roles, career opportunities) → Use **Framework D – Direct Empathy** (1-step, speak to pain)

**How much data do you have on the prospect?**
- Rich data (company news, funding, partnerships) → See **Personalization Tier 1** in Part 2
- Moderate data (job title, company name, industry) → See **Personalization Tier 2** in Part 2
- Minimal data (name and email only) → See **Personalization Tier 3** in Part 2

---

## PART 1: WINNING EMAIL FRAMEWORKS

### Framework A — "GTM Roadmap" (Highest Volume Winner)

**Performance:** Used across outbound agency/consultancy campaigns. Drove a 6.4% positive response rate among all replies. Best suited for B2B services, agency, and consultancy offers.

**Structure (3-step sequence, delays: 1→2→5 days):**

**Email 1 — The Personalized Hook + Case Study**
```
Hi {{first_name}},

[Personalized opener referencing specific company news, partnership, funding round, or recent activity — 1-2 sentences]

This is usually solved by [framing the solution in their language]. For a similar [Industry] company, [specific metric: "we added 54 deals to their sales pipeline in just 10 days" / "added $2.6M+ to their sales pipeline in 6 months"].

Is this something you're focused on this year?

Best,

[Signature]

P.S. I'm reaching out as you are the {{Job Title}}. If this isn't relevant, please feel free to let me know.
```

**Email 2 — The Tangible Deliverable Offer**
```
Hi {{first_name}},

{{company_name}} appears to be targeting {{ICP1}} and {{ICP2}} in the {{Industry}} space.

I'd like to put together a custom GTM Roadmap that outlines a clear action plan for reaching more of those buyers using a modern acquisition system.

Would you be open to a brief call to walk through it together?

Best,

PS: For a similar company, we built a system that added $2.6M+ to their sales pipeline in 6 months.
```

**Email 3 — The Execution Layer**
```
Hi {{first_name}},

Alongside the GTM roadmap, I can also support execution by putting together a focused list of 500 {{ICP1}} that closely match {{company_name}}'s ideal buyer profile.

This helps translate the strategy into a system that can actually be activated.

Would it be useful to review this together?

Best,

PS: I can also show you how we generated $2.6M+ in new sales pipeline in 6 months for a similar company.
```

**Why this works:**
- Email 1 opens with research-backed personalization (company news) — feels human, not bulk
- Each email escalates the value offered (insight → roadmap → roadmap + lead list)
- The case study is repeated but framed differently each time (reinforcement without repetition)
- Specific numbers create credibility ("54 deals in 10 days", "$2.6M in 6 months")
- The P.S. in Email 1 acknowledges their role and gives an easy opt-out (reduces friction)

---

### Framework B — "Free Pilot Program" (Highest Positive Rate)

**Performance:** Used across EdTech product outreach campaigns. Drove a **17.9% positive response rate** among all replies — the best performing framework in the entire dataset. Best suited for SaaS, hardware, or any product that can offer a trial/pilot.

**Structure (2-step sequence, delays: 2→3 days):**

**Email 1 — The No-Risk Offer**
```
Hi {{first_name}},

[Personalized opener — 1 sentence referencing their organization/context]

We're offering select [Region] [organizations] 30-day pilot programs with our [Product] — the same technology that's helped others achieve [specific result: "10+ months improvement in just 8 weeks"].

I can get [product/access] to you next month so you can see the impact firsthand.

Worth discussing the details?

Best,

[Signature]

P.S. If this isn't relevant to you, please let me know.
```

**Email 2 — The Details + Soft CTA**
```
Hi {{first_name}},

[Personalized follow-up opener]

This 30-day pilot includes [product], full support, and impact tracking — all at no cost while you evaluate the results.

Should we schedule a brief call, or is this not a priority right now?

Best,

[Signature]
```

**Why this works:**
- "No cost" / "30-day pilot" removes all risk from the prospect's side
- Specific, measurable outcomes are concrete and verifiable
- Geographic/segment targeting ("select [Region] [organizations]") creates exclusivity
- Email 2 gives them an easy "no" option ("or is this not a priority right now?") which paradoxically increases replies
- Short — each email is under 100 words of body copy

---

### Framework C — "Emotional Storytelling" (Creative Services)

**Performance:** Used across video production and creative services campaigns. Drove strong engagement in creative/media verticals. Best suited for agencies, production companies, and any service that transforms how a brand communicates.

**Structure (2-step sequence, delays: 1→2 days):**

**Email 1 — The Provocative Question**
```
Hi {{first_name}},

[Personalized intro about their company]. How do you emotionally connect audiences with the complex problems?

We work with {{Industry}} companies to transform static documents with mini documentaries that bridge the data-emotion gap. [Case study reference]

Care if I send over the framework?

If not, just let me know.

Best,

[Signature]
```

**Email 2 — The Audit Offer**
```
[AI-personalized storytelling audit copy]

[Signature]

P.S. Shorten your trust-building cycle by turning complex data into clear, human proof. If this isn't relevant, just let me know.
```

**Why this works:**
- Opens with a question that makes them think (not a pitch)
- "Data-emotion gap" is a concept that resonates with decision-makers
- Offers a framework (low commitment) rather than a meeting
- The opt-out is woven naturally into the close

---

### Framework D — "Direct Empathy" (Recruiting)

**Performance:** Used across recruiting outreach campaigns. Single-email approach that generated strong positive response rates. Best suited for recruiting, talent acquisition, and career-focused outreach.

**Structure (1 email, direct send):**

```
{{first_name}},

Looking at your profile, it looks like you've been at {{Company}} for {{Tenure}} years.

Here's what I see talking to [Professionals in their field] every week: too many hours, work that's boring, and 3% annual raises.

I help {{Job Plural}} find roles that actually pay market rate. Better comp. Better balance. Firms that don't treat loyalty like a discount code.

If you're curious what's out there, let's talk. I can get you conversations with hiring managers who are actually hiring and firms that value experience.

Not pushy. Just options.

[Signature]

P.S. I know I'm emailing you on your corporate account — don't reply here. But if you're interested, feel free to reach out to me at [personal email] or shoot me a text.
```

**Why this works:**
- No pleasantries or warm-up — immediately relevant and personal
- Speaks to pain points the prospect ACTUALLY feels (not assumed ones)
- Conversational, almost anti-corporate tone creates trust
- "Not pushy. Just options." is a masterclass in low-pressure CTA
- The P.S. shows awareness of their context (corporate email) and provides alternative contact

---

## PART 2: PROVEN COPYWRITING PATTERNS

### Personalization Patterns That Drive Replies

Based on analyzing the actual sent emails, these personalization approaches appeared in high-performing campaigns:

1. **Company News Reference:** "Saw [Company]'s recent partnership with [Partner] to enhance [Product]." — References real, verifiable events. This appeared in the highest-performing agency and EdTech campaigns.

2. **Funding/Growth Trigger:** "Saw the news about the recent $[X] million in funding. How does an injection of capital like this change how you think about scaling [function] predictably?" — Ties their growth moment to your value prop.

3. **ICP Analysis:** "From my analysis, [Company] targets [ICP1] and [ICP2] in the [Industry] space." — Shows you've done homework on their business model.

4. **Tenure/Profile Reference:** "Looking at your profile, it looks like you've been at [Company] for [X] years." — LinkedIn-sourced personalization that feels human.

5. **Geographic/Segment Specificity:** "We're offering select [Region] [organizations]..." — Regional targeting creates relevance and exclusivity.

### Personalization Depth Tiers

Not every lead comes with the same data. Use the tier that matches what you actually have:

**Tier 1 — Rich Data (company news, funding, partnerships, product launches)**
Use when you have specific, recent intel about the prospect's company. This is the highest-converting tier. Open with a direct reference to the news and connect it to your value prop. Example: "Saw [Company]'s recent partnership with [Partner] to enhance [Product]. As you scale these initiatives, how does that change how you think about [relevant function]?" Best suited for Framework A and Framework B.

**Tier 2 — Moderate Data (job title, company name, industry, ICP)**
Use when you know who they are and what their company does, but don't have a specific news hook. Open with an analysis of their business model or target market. Example: "From my analysis, [Company] targets [ICP1] and [ICP2] in the [Industry] space. I'd like to put together a [deliverable] that outlines a clear action plan for reaching more of those buyers." This is the most common tier and works across all frameworks.

**Tier 3 — Minimal Data (name, email, job title only)**
Use when you have limited prospect data. Lead with an industry-wide pain point or trend rather than company-specific personalization. Example: "Here's what I see talking to [Job Title Plural] every week: [universal pain point]. I help [professionals] [achieve specific outcome]." Best suited for Framework D. For other frameworks at this tier, lean heavily on the value of your offer (pilot, roadmap, audit) rather than personalization depth.

### CTA Patterns (Ranked by Effectiveness)

From highest to lowest engagement based on the data:

1. **Low-commitment deliverable offer:** "Would you be open to get on a call and take a look at the [specific deliverable]?" — Offers something tangible, not just "a chat"
2. **Binary choice with easy out:** "Should we schedule a brief call, or is this not a priority right now?" — Giving them permission to say no increases engagement
3. **Permission-based:** "Care if I send over the framework?" — Asks for a micro-commitment
4. **Curiosity-driven:** "Is this something you're focused on this year?" — Open question that prompts reflection
5. **Direct but pressure-free:** "Not pushy. Just options." — Anti-sales positioning

### P.S. Line Patterns

Every high-performing campaign used P.S. lines. These serve dual purposes — they get read (people scan to the P.S.) and they reduce friction:

1. **Role acknowledgment + opt-out:** "P.S. I'm reaching out as you are the [Job Title]. If this isn't relevant, please feel free to let me know." — Used across the highest-volume outbound campaigns
2. **Case study reinforcement:** "PS: For a similar company, we built a system that added $2.6M+ to their sales pipeline in 6 months." — Repeats social proof in the most-read position
3. **Trust-builder:** "P.S. Shorten your trust-building cycle by turning complex data into clear, human proof."
4. **Context-aware:** "P.S. I know I'm emailing you on your corporate account — don't reply here." — Shows situational awareness

### Spintax Patterns

All high-volume campaigns use spintax for natural variation. Key patterns:

- **Greetings:** `{Hi|Hey|Hello}` — Simple but prevents pattern detection
- **Verbs:** `{appears to be|looks like you're|seems to be}` — Keeps language natural
- **CTAs:** `{open to|up for}`, `{brief|quick}`, `{walk through|review}`
- **Closings:** `{Best|Cheers|Regards|Thanks}`
- **Opt-outs:** `{If this isn't relevant, please feel free to let me know.|But if this isn't relevant, feel free to let me know.|If this doesn't apply to you, please let me know.}`

---

## PART 3: SEQUENCE ARCHITECTURE INSIGHTS

### Optimal Sequence Length

From the data:
- **2-step sequences** dominate the highest positive-reply campaigns (EdTech pilots, creative services, real estate tech)
- **3-step sequences** work for consultancy/agency offers where each email escalates value (GTM roadmap approach)
- **1-step sequences** work for highly targeted, empathy-driven outreach (recruiting)
- Sequences longer than 3 steps showed diminishing returns across the dataset

### Optimal Delay Patterns

Based on campaigns with highest positive reply rates:
- **Email 1 → Email 2:** 2-3 days (sweet spot)
- **Email 2 → Email 3:** 5 days (if using 3-step)
- Campaigns with 1-day delays between all steps had higher bounce and unsubscribe rates

### Subject Line Patterns

High-performing campaigns used:
- **Personalized variable subjects:** `{{Subject 1}}` — AI-generated per-lead subjects performed well at scale
- **Simple question format:** "Worth a chat?" — Used in single-step recruiting campaigns
- **Topical hooks:** "media storytelling audit" — Specific enough to feel relevant, vague enough to create curiosity
- **Empty/thread subjects for follow-ups:** Many follow-ups used empty subject lines (threads under the original)

---

## PART 4: PERFORMANCE BENCHMARKS BY VERTICAL

### Vertical Performance Rankings (by positive reply rate among responses)

1. **EdTech / Education** — 17.9% positive rate — Best performing vertical. Free pilot offers + measurable outcomes + geographic targeting
2. **Assessments / HR Tech** — ~6.5% positive rate — Enterprise and SME segmentation works well
3. **Agency / Consultancy (B2B Services)** — 6.4% positive rate — GTM roadmap + escalating value + specific case studies
4. **Video / Creative Services** — ~6.5% positive rate — Emotional storytelling angle differentiates
5. **Real Estate Tech** — Strong performance — AI-personalized copy at scale
6. **Recruiting / Talent Acquisition** — Strong performance — Empathy-driven, anti-corporate tone
7. **Manufacturing / Insurance / Traditional Industries** — Lower positive rate — Traditional industries are harder to engage via cold email; requires more touches and different value props

### Tone and Voice Guide by Vertical

Each vertical responds to a different writing voice. Match your tone to the audience:

**EdTech / Education** — Professional and outcome-focused. Decision-makers in education respond to data-backed claims and student impact language. Avoid salesy language. Use phrases like "measurable outcomes", "impact tracking", "no cost to evaluate". Keep it structured and clear — these are administrators managing tight budgets who need to justify every decision.

**Agency / Consultancy / B2B Services** — Confident and strategic. Speak as a peer, not a vendor. Use business language like "revenue engine", "acquisition system", "GTM roadmap". Show that you understand their business model and ICP. These prospects respect specificity — name their target buyers, reference their industry, and offer tangible deliverables rather than vague conversations.

**Assessments / HR Tech** — Solution-oriented and segmented. Tailor the tone based on whether you're reaching enterprise vs. SME buyers. Enterprise contacts respond to scalability and ROI language. SME contacts respond to ease of implementation and quick wins. In both cases, lead with the problem your product solves, not the product itself.

**Video / Creative Services** — Provocative and conceptual. Creative buyers are allergic to generic outreach. Lead with an insight or a challenging question that makes them think. Use language around storytelling, emotion, and audience connection. Offer frameworks and audits, not demos — creative people want to see how you think before they talk to you.

**Real Estate Tech** — Direct and results-driven. Real estate professionals are action-oriented and time-pressed. Get to the point fast. Lead with specific numbers (leads generated, deals closed, time saved). Use industry-specific language. Keep emails under 80 words if possible.

**Recruiting / Talent Acquisition** — Conversational and empathetic. Drop the corporate tone entirely. Write like a human texting a friend who deserves better. Use short sentences, sentence fragments, and real talk about pain points (boring work, low raises, long hours). Never sound like a recruiter — sound like someone who gets it.

**Manufacturing / Insurance / Traditional Industries** — Formal and credential-heavy. Traditional industries are skeptical of cold outreach. Lead with credibility signals (years of experience, recognizable results, industry-specific knowledge). Use straightforward language — no jargon, no buzzwords. These prospects need more touches (3-step sequences minimum) and respond better to phone follow-ups paired with email.

### Day-of-Week Performance

From the day-wise positive reply data across 1M+ emails:
- **Monday:** Highest spike days — consistently the strongest day for positive replies
- **Wednesday & Thursday:** Consistently strong secondary performers
- **Tuesday & Friday:** Moderate, reliable volume
- **Saturday & Sunday:** Near zero (avoid sending on weekends)

### Monthly Trends

- **January:** Massive spike in positive replies (strongest month) — new year momentum, fresh budgets
- **February:** Sustained high volume, strong continuation
- **November-December:** Building momentum, especially first three weeks of December
- **June-October:** Moderate, steady flow
- **March-May:** Growing volume as campaigns ramp up

---

## PART 5: HOW TO USE THIS SKILL

### When Writing New Email Sequences

1. **Start with the Quick Decision Framework** at the top of this skill to select the right framework (A/B/C/D) based on what you're selling
2. **Determine your personalization tier** (Tier 1/2/3) from Part 2 based on what data you actually have about the prospect
3. **Choose sequence length** based on Part 3 guidelines (2 steps for product offers, 3 for services, 1 for highly targeted)
4. **Match your tone** to the vertical using the Tone and Voice Guide in Part 4
5. **Apply spintax** to all variable elements using the patterns in Part 2
6. **Include a P.S. line** — every single high-performing campaign used one
7. **Always include an opt-out** that feels natural, not corporate

### When Reviewing/Optimizing Existing Sequences

Check against these failure patterns (common in negative-sentiment replies like "Not Interested" and "Do Not Contact"):

- **Too long** — Body copy should be under 120 words per email
- **No personalization** — Generic emails get flagged or ignored
- **No tangible offer** — "Let's chat" without a deliverable is weak
- **No case study** — Missing social proof with specific numbers
- **No opt-out** — Increases spam complaints and negative sentiment
- **Too many steps** — More than 3 emails in a sequence without a reply
- **Wrong send timing** — Sending on weekends or late Friday

### Critical Rules (Never Break These)

1. **Never lead with your product** — Lead with their world (news, pain point, context)
2. **Always include specific metrics** in case studies — "54 deals in 10 days" not "significant pipeline growth"
3. **Every email must offer something tangible** — A roadmap, a list, a framework, a pilot, an audit
4. **Keep P.S. lines** — They're the most-read part of cold emails after the subject line
5. **Use spintax** — Any sequence sending to more than 50 people needs variation
6. **Match tone to vertical** — See the Tone and Voice Guide in Part 4 for specific guidance per industry
7. **First email personalization is non-negotiable** — The opener must reference something specific to them
8. **Follow-ups should escalate value, not repeat** — Each email adds a new reason to respond
